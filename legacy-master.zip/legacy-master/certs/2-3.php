<p class="lead center"><?php echo _('On profit'); ?></p>
<?php echo _('Money is essential. You need it to buy better hardware and research stronger softwares. So, how to get it?'); ?>
<br/>
<br/>
<?php echo _('Installing viruses is the easier way of getting money.'); ?><br/>
<?php echo _('As said before, you have three viruses that generate money: <em>Spam</em>, <em>Miner</em> and <em>Warez</em>. Install one of them and use the <em>Virus Collector</em> software to profit.'); ?>
<br/>
<br/>
<?php echo _('You can opt to work on <em>missions</em>. You can see the current offers at the Missions link, on the left sidebar.'); ?><br/>
<?php echo _('In order to see the data of the mission, you need to "know" who is offering it, i.e., have them listed on your Hacked Database.'); ?><br/>
<?php echo _('Missions are offered by companies. You can find some on the First Whois.'); ?>
<br/>
<br/>
<?php echo _('Another way is hacking bank accounts and transfering the funds to you.'); ?><br/>
<?php echo _('<em>Exploit attack</em> and bank account cracking will be seen later.'); ?>
<br/>
<br/>
<?php echo _('You have some work to do now. I\'m done helping you. Bye.'); ?>

<br/>

<div class="center">
    <a class="btn btn-danger" href="university?opt=certification&learn=2&page=2"><?php echo _('Previous page'); ?></a> | <a class="btn btn-success" href="university?opt=certification&complete=<?php echo md5('cert2'.$_SESSION['id']); ?>"><?php echo _('Complete this certification'); ?></a>
</div>