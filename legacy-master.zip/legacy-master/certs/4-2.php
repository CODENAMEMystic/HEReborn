<p class="lead center"><?php echo _('Performing a DDoS Attack'); ?></p>

<?php echo _('Here is how you do it. You will install the <em>DDoS virus</em> on as many computers as you can.'); ?><br/>
<?php echo _('The more servers with the DDoS virus installed you have, more powerful your attack will be.'); ?>
<br/>
<br/>
<?php echo _('After having at least three running DDoS viruses, you must launch the DDoS attack against the victim.'); ?><br/>
<?php echo _('In order to do that, you need a <em>DDoS Breaker</em> software.'); ?>
<br/>
<br/>
<?php echo _('That\'s it. Insert the target IP on the DDoS breaker and wait until the attack is completed.'); ?>
<br/>
<br/>
<?php echo _('A few considerations:'); ?><br/>
- <?php echo _('You need to have the target server on your Hacked Database.'); ?><br/>
- <?php echo _('You need to have at least three running viruses.'); ?><br/>
- <?php echo _('The power of an attack depends, mainly, on the total CPU power of all servers running the viruses.'); ?><br/>
- <?php echo _('When an attack is launched, the DDoS logs will be on the target computer and <em>every</em> server with a DDoS virus.'); ?>
<br/>
<br/>
<?php echo _('Your DDoS attack will only damage the target hardware if a minimum power is achieved.'); ?><br/>
<?php echo _('It is recommended that you have at least 5 powerful servers.'); ?>
<br/>
<br/>
<?php echo _('The victim is said <em>seized</em> if you manage to reduce her hardware to the minimal configuration possible.'); ?><br/>
<?php echo _('Be careful when repeatedly attacking someone, though. The Safenet and the FBI tracks powerful attacks.'); ?>

<br/>
<br/>

<div class="center">
    <a class="btn btn-danger" href="university?opt=certification&learn=4&page=1"><?php echo _('Previous page'); ?></a> | <a class="btn btn-success" href="university?opt=certification&learn=4&page=3">Safenet? FBI?</a>
</div>