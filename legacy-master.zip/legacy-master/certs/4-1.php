<p class="lead center"><?php echo _('Advanced Hacking'); ?></p>

<?php echo _('First of all, congratulations, not everyone reaches this point (:'); ?><br/>
<?php echo _('Let me introduce you the <strong>DDoS</strong> (<em>Distributed Denial of Service</em>).'); ?>
<br/>
<br/>
<?php echo _('A DDoS attack is an attempt to overload the victim\'s servers by exhausting it\'s resources.'); ?><br/>
<?php echo _('Imagine thousands of computers connecting at the same time on a single server. That\'s a DDoS attack.'); ?>
<br/>
<br/>
<?php echo _('You can perform DDoS attacks on this game, with the intent of disabling the victim\'s service (i.e., the server gets offline).'); ?><br/>
<?php echo _('A DDoS attack will also damage the victim\'s hardware. The damage inflict depends of the attack power.'); ?>

<br/>
<br/>

<div class="center">
    <a class="btn btn-success" href="university?opt=certification&learn=4&page=2"><?php echo _('Got it. How do I perform an attack?'); ?></a>
</div>