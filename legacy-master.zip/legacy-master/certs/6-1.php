Only this one<br/>
<br/>
<a href="university?opt=certification&complete=<?php echo md5('cert1'.$_SESSION['id']); ?>">Complete!</a>