<?php
header("Location: https://docs.google.com/spreadsheets/d/1rcl59dZ9nPcKqoeFwWQbdZyoMbFml97LvAwx1uA3Udg/edit#gid=0");
?>