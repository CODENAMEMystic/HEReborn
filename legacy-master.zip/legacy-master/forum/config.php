<?php

// 2019: There are some small modifications added to the PHPBB code in order to integrate smoothly with Legacy.
// 2019: Good look finding them :)

// phpBB 3.0.x auto-generated configuration file
// Do not change anything in this file!
$dbms = 'mysqli';
$dbhost = 'localhost';
$dbport = '';
$dbname = 'forum';
$dbuser = 'forum';
$dbpasswd = 'REDACTED';
$table_prefix = 'phpbb_';
$acm_type = 'file';
$load_extensions = '';

@define('PHPBB_INSTALLED', true);
// @define('DEBUG', true);
// @define('DEBUG_EXTRA', true);
