<?php

static $badgeArrayUser = Array(
    
    '1' => Array(
        
        'NAME' => 'Developer',
        'DESC' => '',
        
    ),
    
    '2' => Array(
        
        'NAME' => 'Administrator',
        'DESC' => '',
        
    ),
    
    '3' => Array(
        
        'NAME' => 'Moderator',
        'DESC' => '',
        
    ),
    
    '4' => Array(
        
        'NAME' => 'Translator',
        'DESC' => '',
        
    ),    
    
    '5' => Array(
        
        'NAME' => 'Premium',
        'DESC' => '',
        
    ),     
    
    '6' => Array(
        
        'NAME' => 'Beta tester',
        'DESC' => '',
        
    ),     
    
    '7' => Array(
        
        'NAME' => 'Best player',
        'DESC' => 'First ranked at the end of the round',
        
    ),
    
    '8' => Array(
        
        'NAME' => 'Runner up',
        'DESC' => 'Second ranked at the end of the round',
        
    ),
    
    '9' => Array(
        
        'NAME' => '3rd placed',
        'DESC' => '3rd placed at the end of the round',
        
    ),
    
    '10' => Array(
        
        'NAME' => 'Almost there',
        'DESC' => 'Ranked among 10 top players of the round',
        
    ),  
    
    '11' => Array(
        
        'NAME' => 'Doom!',
        'DESC' => 'Launched a doom attack',
        
    ),
    
    '12' => Array(
        
        'NAME' => 'ANTI-Doom!',
        'DESC' => 'Disabled a doom attack',
        
    ),
    
    '13' => Array(
        
        'NAME' => 'DDoS!',
        'DESC' => 'Launched a DDoS attack',
        
    ),
                
    
);


static $badgeArrayClan = Array(
    
    '1' => Array(
        
        'NAME' => 'Best clan',
        'DESC' => 'Winner',
        
    ),
    
    '2' => Array(
        
        'NAME' => 'Runner up',
        'DESC' => 'Almost winner',
        
    ),    
    
    '3' => Array(
        
        'NAME' => '3rd placed',
        'DESC' => 'Close..',
        
    ),
    
);

?>
